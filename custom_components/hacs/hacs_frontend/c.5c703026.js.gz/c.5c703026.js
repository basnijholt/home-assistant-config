const e=()=>new Promise((e=>{var t;t=e,requestAnimationFrame((()=>setTimeout(t,0)))}));export{e as n};
