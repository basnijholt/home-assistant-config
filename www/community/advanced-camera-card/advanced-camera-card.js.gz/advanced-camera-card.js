import"./card-d57b089c.js";
