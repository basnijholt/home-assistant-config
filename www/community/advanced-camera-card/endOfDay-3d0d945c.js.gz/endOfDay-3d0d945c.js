import{d5 as r}from"./card-fdaaae6b.js";function o(o){const s=r(o);return s.setHours(23,59,59,999),s}export{o as e};
