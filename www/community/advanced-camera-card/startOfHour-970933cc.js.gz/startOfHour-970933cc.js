import{dT as t}from"./card-1c91ee9b.js";function s(s){const n=t(s);return n.setMinutes(59,59,999),n}function n(s){const n=t(s);return n.setMinutes(0,0,0),n}export{s as e,n as s};
